package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class ProfilePage {
	WebDriver driver;
	By headername=By.xpath("//*[@class='profile main']/header/h1");
	By visibleusername=By.xpath("//div[@class='profile-gravatar is-in-sidebar']/h2");
	By firstname=By.xpath("//input[@id='first_name']");
	By lastname=By.xpath("//input[@id='last_name']");
	By displayname=By.xpath("//input[@id='display_name']");
	By aboutme=By.xpath("//textarea[@id='description']");
	By hideprofiletoggle=By.xpath("//span[@class='components-form-toggle']/input");
	By labeltext=By.xpath("//label[@class='components-toggle-control__label']");
	By saveprofilebutton=By.xpath("//button[contains(text(), 'Save profile')]");
	By savedsuccessmessage=By.xpath("//div[@id='notices']/div/span[2]/span");
public ProfilePage(WebDriver driver) {
		
		this.driver = driver;
	}

	public WebElement getHeadername() {
		return driver.findElement(headername);
		
	}
	
	public WebElement getVisibleusername() {
		return driver.findElement(visibleusername);
		
	}
	
	public WebElement getFirstname() {
		return driver.findElement(firstname);
	}
	
	public WebElement getLastName() {
		return driver.findElement(lastname);
		
	}
	
	public WebElement getDisplayname() {
		return driver.findElement(displayname);
	}
	
	public WebElement getAboutme() {
		return driver.findElement(aboutme);
	}
	
	public WebElement getHideProfieToggle() {
		return driver.findElement(hideprofiletoggle);
	}
	
	public WebElement getLabelText() {
		return driver.findElement(labeltext);
	}
	
	public WebElement getProfileButton()
	{
		return driver.findElement(saveprofilebutton);
	}
	
	public WebElement getSaveSuccessMessage() {
		return driver.findElement(savedsuccessmessage);
	}
}
