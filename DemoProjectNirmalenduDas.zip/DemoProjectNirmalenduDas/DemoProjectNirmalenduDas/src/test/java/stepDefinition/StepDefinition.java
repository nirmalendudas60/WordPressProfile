package stepDefinition;

import static org.testng.Assert.assertFalse;
import static org.testng.Assert.assertTrue;

import java.io.IOException;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import junit.framework.Assert;
import pageObjects.LoginPage;
import pageObjects.ProfilePage;
import resources.Base;

public class StepDefinition extends Base {

@Given("Initialize the Chrome Browser and launch the {string}")
public void initialize_the_chrome_browser_and_launch_the(String string) throws IOException {
    // Write code here that turns the phrase above into concrete actions
	driver = intializedriver();
	driver.get(url1);
	log.info("Driver is initialized");
}
@Given("Navigate to WordPress Login Page")
public void navigate_to_word_press_login_page() {
    // Write code here that turns the phrase above into concrete actions
	driver.manage().window().maximize();
	log.info("User is o login page");
			
}
@When("User login into application with {string} and {string}")
public void user_login_into_application_with_and(String string1, String string2) throws InterruptedException {
    // Write code here that turns the phrase above into concrete actions
	LoginPage lp = new LoginPage(driver);
	lp.getUsername().sendKeys(string1);
	lp.getContinueButton().click();;
	lp.getPassword().sendKeys(string2);
	lp.getLoginButton().click();;
	Thread.sleep(1000);
}
@Then("My Profile page is populated and {string} page header should be displayed")
public void my_profile_page_is_populated_and_page_header_should_be_displayed(String string3) {
    // Write code here that turns the phrase above into concrete actions
	ProfilePage pp = new ProfilePage(driver);
	Assert.assertEquals(pp.getHeadername().getText(), string3);
	log.info("Hide my gravtar profile text is clearly visible");
}

@Then("^Username \"([^\"]*)\" should be displayed at the My Profile Page$")
public void username_something_should_be_displayed_at_the_my_profile_page(String strArg1) throws Throwable {
	ProfilePage pp = new ProfilePage(driver);
	Assert.assertEquals(pp.getVisibleusername().getText(), strArg1);
	log.info("Visible Username successfully validated");
}

@Given("^Navigate to My Profile Page and \"([^\"]*)\" page header is displayed$")
public void navigate_to_my_profile_page_and_something_page_header_is_displayed(String strArg2) throws Throwable {
	ProfilePage pp = new ProfilePage(driver);
	Assert.assertEquals(pp.getHeadername().getText(), strArg2);
	log.info("Hide my gravtar profile text is clearly visible");
}

@When("^First Name is \"([^\"]*)\", Last Name is \"([^\"]*)\" and About Me is \"([^\"]*)\"$")
public void first_name_is_something_last_name_is_something_and_about_me_is_something(String strArg3, String strArg4, String strArg5) throws Throwable {
	ProfilePage pp = new ProfilePage(driver);
	pp.getFirstname().sendKeys(strArg3);
	pp.getLastName().sendKeys(strArg4);
	pp.getAboutme().sendKeys(strArg5);
}

@Then("^Save My Profile Details button enabled is \"([^\"]*)\"$")
public void save_my_profile_details_button_enabled_is_something(String strArg6) throws Throwable {
	ProfilePage pp = new ProfilePage(driver);
	assertTrue(pp.getProfileButton().isEnabled());
	log.info("Profile displayed is "+strArg6);
	if(pp.getProfileButton().isEnabled())
	{
		System.out.println("true");
	}
	else
	{
		System.out.println("false");
	}
}

@Then("^Clear all fields$")
public void clear_all_fields() throws Throwable {
	clearAllProfileData();
}

}
	
