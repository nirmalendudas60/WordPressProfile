package CucumberOptions;

import org.junit.runner.RunWith;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;

//feature
//stepDefinition
@RunWith(Cucumber.class)
@CucumberOptions(
		features = "src/test/java/Feature",
		glue = "stepDefinition")
public class TestRunner {

	
}
